import Foundation

func isLeap(year: Int) -> Bool
{ return year % 400 == 0 || ((year % 100 != 0) && year % 4 == 0) }


let dateFormatter = NSDateFormatter()
dateFormatter.dateFormat = "yyyy-MM-dd"


func julianDate(year: Int, month: Int, day: Int) -> Int
{
    let S:NSDate = dateFormatter.dateFromString("1900-01-01")!
    let E:NSDate = dateFormatter.dateFromString("\(year)-\(month)-\(day)")!
    return (NSCalendar.currentCalendar().components(.Day, fromDate: S, toDate: E, options: [])).day
}



julianDate(1960, month:  9, day: 28)

julianDate(1900, month:  1, day: 1)

julianDate(1900, month: 12, day: 31)

julianDate(1901, month: 1, day: 1)

julianDate(1901, month: 1, day: 1) - julianDate(1900, month: 1, day: 1)

julianDate(2001, month: 1, day: 1) - julianDate(2000, month: 1, day: 1)

isLeap(1960)

isLeap(1900)

isLeap(2000)


